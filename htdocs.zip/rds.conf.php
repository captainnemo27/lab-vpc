<?php $RDS_URL=""; $RDS_DB=""; $RDS_user=""; $RDS_pwd=""; ?>
